#!/bin/bash

sudo apt-fast install pandoc libcurl4-openssl-dev libssl-dev -y
sudo apt-fast install libgtk2.0-dev libxml2-dev libcurl4-gnutls-dev libgdal-dev libudunits2-dev libsodium-dev bwidget -y
sudo apt-fast install libx11-dev mesa-common-dev libglu1-mesa-dev -y
sudo apt-fast install cmake libdatetime-perl libxml-simple-perl libdigest-md5-perl git default-jre bioperl -y

