
#----- Libraries ----
pks = c(
'shinyjs', 'ggdist', 'gghalves', 'readr', 'scales', 'patchwork', 'foreach', 'tidyverse', 'skimr', 'DataExplorer', 'dlookr', 'data.table', 'doParallel', 'doSNOW', 'rpart', 'stringi', 'caret', 'corrplot', 'MASS', 'pROC'
)
if(!requireNamespace(pks, quietly = T)){
  install.packages(pks)
}
lapply(pks, require, character.only = T)


#---- UI ----
ui = fluidPage(
  uiOutput('page_Start'),
  theme = shinythemes::shinytheme('slate'),
  useShinyjs()
)


#---- Server ----
server = function(input, output, session) {
  threads = detectCores()
  setwd(tempdir())
  options(shiny.maxRequestSize = 100 * 1024 ^ 2)
  
  ##---- Main Page Tabs ----
  output$page_Start <- renderUI({
    navbarPage(
      id = 'MainTabs', title = 'Tiny-ML', fluid = T, collapsible = F, 
      theme = shinythemes::shinytheme('slate'),
      tabPanel('Wrangling', uiOutput('page_Wrangling')), 
      tabPanel('Modeling', uiOutput('page_Modeling')),
      tabPanel('Prediction',  uiOutput('page_Prediction'))
    )
  })
  
  ###---- Wrangling Main Tab ----
  output$page_Wrangling = renderUI({
    sidebarLayout(
      sidebarPanel(
        ###---- Panel Left ----
        div(style = "margin-left: 5%; margin-right: 5%; display: inline-block; 
            width: 90%; text-align: center;",
            
        ), 
        width = 4,
        ####---- Slots ----
        uiOutput('Wrangling_slot_1'), uiOutput('Wrangling_slot_2'), 
        uiOutput('Wrangling_slot_3'), uiOutput('Wrangling_slot_4'), 
        uiOutput('Wrangling_slot_5'), uiOutput('Wrangling_slot_6'), 
        ###---- Notification ----
        tags$head(
          tags$style(
            '.shiny-notification {position: fixed;top:30%;left:50%} '
          )
        )
      ),
      ###---- Main Panel ----
      mainPanel(
        tags$style(
          HTML('.dataTables_wrapper .dataTables_length, 
              .dataTables_wrapper .dataTables_filter, 
              .dataTables_wrapper .dataTables_info, 
              .dataTables_wrapper .dataTables_processing, 
              .dataTables_wrapper .dataTables_paginate {color: #ffffff;}
              thead {color: #ffffff;}
              tbody {color: #000000;}'
          )
        ),
        ###---- Output Panel ----
        uiOutput('Wrangling_panel'),
        fluid = T
      )
    )
  })
  #>---- Wrangling Panel Tabs ----
  output$Wrangling_panel = renderUI({
    tabsetPanel(
      tabPanel('Input Data', DT::dataTableOutput('Wrangling_input_data')),
      tabPanel('Summary', verbatimTextOutput('Wrangling_eda1_input_data')),
      tabPanel('Correlation', plotOutput('Wrangling_eda2_input_data')),
      tabPanel('FeatImp', plotOutput('Wrangling_eda3_input_data')),
      tabPanel("Class",plotOutput('Wrangling_eda4_input_data'))
      
    )
  })
  
  #>---- Wrangling_slot_1: Load data ----
  output$Wrangling_slot_1 = renderUI({
    div(style = 'margin-left: 1%; margin-right: 1%; display: inline-block; 
        width: 98%; text-align: center; margin-top: -10%;', 
        fileInput(
          inputId = 'Load_Data', label = 'File to analyse',
          accept = '.csv', multiple = F
        )
    )
  })
  #>---- Wrangling_slot_2: Separator ----
  output$Wrangling_slot_2 = renderUI({
    div(style = 'margin-left: 1%; margin-right: 1%; display: inline-block; 
        width: 98%; text-align: center; margin-top: -10%;',  
        radioButtons(
          inputId = 'Separator_Data', label = 'Separator',
          choices = c(Comma = ',', Semicolon = ';', Tab = '\t'),
          selected = ',', inline = T
        )
    )
  })
  #>---- Wrangling_slot_3:Run/Clear Button ----
  output$Wrangling_slot_3 = renderUI({
    splitLayout(
      div(style = 'margin-left: 10%; margin-right: 5%; display: inline-block;
          width: 80%; text-align: center; margin-top: 5%;',
          actionButton(
            inputId = 'Wrangling_run', label = 'Run', style = 'width: 100%;'
          )
      ),
      div(style = 'margin-left: 7%; margin-right: 10%; display: inline-block;
          width: 80%; text-align: center; margin-top: 5%;',
          actionButton(
            inputId = 'Wrangling_clear', label = 'Clear', style = 'width: 100%;'
          )
      )
    )
  })
  #>---- Wrangling_slot_4: Show table ----
  output$Wrangling_slot_4 = renderUI({
    div(style = 'margin-left: 1%; margin-right: 1%; display: inline-block; 
        width: 98%; text-align: center; margin-top: 10%;', 
        radioButtons(
          inputId = 'Show_Input_Data', label = 'Show data tables',
          choices = c(All = 'all', first_5 = 'F5', last_5 = 'L5'),
          selected = 'F5', inline = T
        )
    )
  })
  
  #>---- Wrangling_slot_5: Train/Test separator ----
  output$Wrangling_slot_5 = renderUI({
    div(style = 'margin-left: 1%; margin-right: 1%; display: inline-block; 
        width: 98%; text-align: center; margin-top: 0%;', 
        sliderInput(
          inputId = 'Train_Test_Separator', label = 'Train (%)',
          min = 50, max = 95, value = 80, step = 5, ticks = F
        )
    )
  })
  #>---- Wrangling_slot_6: Download Results Button ----
  output$Wrangling_slot_6 = renderUI({
    div(style = 'margin-left: 5%; margin-right: 5%; display: inline-block;
          width: 90%; text-align: center;',
        downloadButton(
          outputId = 'Wrangling_result', label = 'Results', style = 'width: 100%;'
        )
    )
  })
  output$Wrangling_result = downloadHandler(
    filename = function(){
      paste0('Empty_File.txt')
    },
    content = function(file){
      writeLines('Empty', file)
    }
  )
  #>---- Clear Script ----
  observeEvent(
    input$Wrangling_clear, {
      #---- Clear Input Data ----
      output$Wrangling_input_data = DT::renderDataTable({
        NULL
      })
      #---- Clear Summary ----
      output$Wrangling_eda1_input_data = renderPrint({
        NULL
      })
      #---- Clear Correlation ----
      output$Wrangling_eda2_input_data = renderPlot({
        NULL
      })
      #---- Clear FeatImp ----
      output$Wrangling_eda3_input_data = renderPlot({
        NULL
      })
      #---- Clear Class ----
      output$Wrangling_eda4_input_data = renderPlot({
        NULL
      })
      #---- Clear download ----
      output$Wrangling_result = downloadHandler(
        filename = function(){
          paste0('Empty_File.txt')
        },
        content = function(file){
          writeLines('Empty', file)
        }
      )
    })
  
  #>---- Run Script ----
  observeEvent(
    input$Wrangling_run, {
      req(input$Load_Data)
      withProgress(message = 'Processing...', value = 0, {
        # Load file
        InputTab = NULL
        file_status = length(grep('\\.csv$', input$Load_Data$datapath))
        
        if(file_status == 1){
          InputTab = read.csv(input$Load_Data$datapath, header = T, sep = input$Separator_Data)
          
          if(ncol(InputTab) > 2){
            #>>---- Wrangling Process ----
            # Features names to lower and remove whitespace
            names(InputTab) = stringi::stri_trans_tolower(names(InputTab))
            names(InputTab) = gsub(' ', '_', names(InputTab))
            
            # ID and Class as factor
            InputTab = as.data.frame(InputTab)
            id = as.factor(InputTab$id)
            class = as.factor(InputTab$class)
            
            # Remove special characters in Class names
            InputTab$class = gsub('[[:punct:]]', '_', InputTab$class)
            
            # Creating ID column if not exist
            if(length(grep(TRUE, names(InputTab) == 'id')) != 1){
              temp_table = data.frame(id = stringi::stri_join(rep('A', nrow(InputTab)), c(1:nrow(InputTab))))
              InputTab = bind_cols(temp_table, InputTab)
            }
            
            #>>---- Data Table: Input data ----
            dt_input_data = reactive({
              if(input$Show_Input_Data == 'all'){
                InputTab
              } else if (input$Show_Input_Data == 'F5'){
                head(InputTab, 5)
              }
              else if (input$Show_Input_Data == 'L5'){
                tail(InputTab, 5)
              }
            })
            output$Wrangling_input_data = DT::renderDataTable({
              dt_input_data()
            }, rownames = F)
            
            #>>---- EDA 1 ----
            r1 = skimr::skim(InputTab)
            sink('Tiny_Wrangling_1_Summary.txt')
            print(r1)
            sink()
            
            output$Wrangling_eda1_input_data = renderPrint({
              r1
            })
            
            #>>---- EDA 2 ----
            if(ncol(InputTab) > 3){
              Cor_Matrix = cor(InputTab[, -c(1, ncol(InputTab))], use = 'everything', method = 'spearman')
              write.table(Cor_Matrix, 'Tiny_Wrangling_2A_Attribute_Correlation_Matrix.csv', row.names = F, sep = ',')

              pdf('Tiny_Wrangling_2B_Attribute_Correlation_Matrix.pdf')
              corrplot::corrplot(Cor_Matrix, method = 'circle')
              dev.off()
              Sys.sleep(1)

              output$Wrangling_eda2_input_data = renderPlot({
                corrplot::corrplot(Cor_Matrix, method = 'circle')
              })
            }else{
              output$Wrangling_eda2_input_data = renderPlot({
                text = paste('\n   Dataset have only 1 feature!\n',
                             ' You need at least 2 features to modeling process!')
                ggplot() + 
                  annotate('text', x = 4, y = 25, size = 8, label = text) + 
                  theme_void()
              })
            }
            
            #>>---- EDA 3 ----
            if(ncol(InputTab) > 3){
              cl = makeCluster(round(threads * 0.9, 0), type = 'SOCK')
              registerDoSNOW(cl)
              controlFI = caret::trainControl(method = 'repeatedcv', number = 10, repeats = 10)
              set.seed(151)
              modelFI = caret::train(as.factor(class) ~ ., InputTab[, -1], 
                                     method = 'rf', metric = 'Accuracy', 
                                     trControl = controlFI, 
                                     importance = T, allowParallel = T
              )
              stopCluster(cl)
              
              importance = caret::varImp(modelFI, scale = TRUE)
              Imp = as.data.frame(importance$importance)
              Imp[, 1] = row.names(Imp)
              names(Imp) = c('Features', 'Percentage')
              Imp = Imp[order(Imp$Percentage, decreasing = T), ]
              write_csv(Imp, 'Tiny_Wrangling_3A_Ranking_of_Features_Importance.csv')
              
              feat_imp_plot = ggplot(importance) +
                theme_minimal()
              ggsave('Tiny_Wrangling_3B_Ranking_of_Features_Importance.pdf', plot =  feat_imp_plot, device =  'pdf')
              
              output$Wrangling_eda3_input_data = renderPlot({
                ggplot(importance) + 
                  theme_minimal()
              })
            }else{
              output$Wrangling_eda3_input_data = renderPlot({
                text = paste('\n   Dataset have only 1 feature!\n',
                             ' You need at least 2 features to modeling process!')
                ggplot() + 
                  annotate('text', x = 4, y = 25, size = 8, label = text) + 
                  theme_void()
              })
            }
            
            #>>---- EDA 4 ----
            train_A = reactive({
              set.seed(51)
              index_train = caret::createDataPartition(InputTab$class, 1, as.numeric(input$Train_Test_Separator) / 100)[[1]]
              InputTab[index_train, ]
            })
            test_A = reactive({
              set.seed(51)
              index_train = caret::createDataPartition(InputTab$class, 1, as.numeric(input$Train_Test_Separator) / 100)[[1]]
              InputTab[-index_train, ]
            })
            class_plot = reactive({
              class_input_data = InputTab %>% count(class)
              pclass_1 = ggplot(data = class_input_data, aes(x = class, y = n)) +
                geom_bar(stat = 'identity', fill = 'darkblue') +
                geom_text(aes(x = class, y = n, label = n), position = position_stack(vjust = 0.5)) +
                xlab('Class') +
                ylab('Frequency') +
                ggtitle('Input Data') +
                theme(plot.title = element_text(hjust = 0.5)) +
                theme_minimal()
              
              class_train = train_A() %>% count(class)
              pclass_2 = ggplot(data = class_train, aes(x = class, y = n)) +
                geom_bar(stat = 'identity', fill = 'darkred') +
                geom_text(aes(x = class, y = n, label = n), position = position_stack(vjust = 0.5)) +
                xlab('Class') +
                ylab('Frequency') +
                ggtitle('Train Data') +
                theme(plot.title = element_text(hjust = 0.5)) +
                theme_minimal()
              
              class_test = test_A() %>% count(class)
              pclass_3 = ggplot(data = class_test, aes(x = class, y = n)) +
                geom_bar(stat = 'identity', fill = 'darkblue') +
                geom_text(aes(x = class, y = n, label = n), position = position_stack(vjust = 0.5)) +
                xlab('Class') +
                ylab('Frequency') +
                ggtitle('Test Data') +
                theme(plot.title = element_text(hjust = 0.5)) +
                theme_minimal()
              
              plots = ((pclass_1) | pclass_2 / pclass_3) + plot_layout(ncol = 2, guides = 'collect')
              ggsave('Tiny_Wrangling_4_Class_Distribution_by_Dataset.pdf', plot =  plots, device =  'pdf')
              plots
            })
            
            output$Wrangling_eda4_input_data = renderPlot({
              class_plot()
            })
            
            #>>---- Train ----
            train_dataset = reactive({
              set.seed(51)
              index_train = caret::createDataPartition(InputTab$class, 1, as.numeric(input$Train_Test_Separator) / 100)[[1]]
              train = InputTab[index_train, ]
              
              # Removing ID and Class
              classes_train = train$class
              id_train = train$id
              if(ncol(train) >3){
                train = train[, -c(grep('^id$|^class$', names(train)))]
              }else{
                id_class = grep('^id$|^class$', names(train))
                f1_name = names(train)[-id_class]
                train = as.data.frame(train[, -id_class])
                names(train) = f1_name
              }
              
              
              # Generating new features (x^2 and x^0.5)
              train_2 = foreach(i = 1:ncol(train), .combine = cbind) %do% {
                train[, i] ** 2
              }
              train_2 = as.data.frame(train_2)
              for(i in 1:ncol(train_2)){
                names(train_2)[i] = stringi::stri_join(c(names(train)[i], '2'), collapse = '_')
              }
              train_0.5 = foreach(i = 1:ncol(train), .combine = cbind) %do% {
                train[, i] ** 0.5
              }
              train_0.5 = as.data.frame(train_0.5)
              for(i in 1:ncol(train_0.5)){
                names(train_0.5)[i] = stringi::stri_join(c(names(train)[i], '0.5'), collapse = '_')
              }
              trainA = data.frame(id = id_train)
              trainB = data.frame(class = classes_train)
              bind_cols(trainA, train, train_2, train_0.5, trainB)
            })
            
            #>>---- Test ----
            test_dataset = reactive({
              set.seed(51)
              index_train = caret::createDataPartition(InputTab$class, 1, as.numeric(input$Train_Test_Separator) / 100)[[1]]
              test = InputTab[-index_train, ]
              
              # Removing ID and Class
              classes_test = test$class
              id_test = test$id
              if(ncol(test) >3){
                test = test[, -c(grep('^id$|^class$', names(test)))]
              }else{
                id_class = grep('^id$|^class$', names(test))
                f1_name = names(test)[-id_class]
                test = as.data.frame(test[, -id_class])
                names(test) = f1_name
              }
              
              # Generating new features (x^2 and x^0.5)
              test_2 = foreach(i = 1:ncol(test), .combine = cbind) %do% {
                test[, i] ** 2
              }
              test_2 = as.data.frame(test_2)
              for(i in 1:ncol(test_2)){
                names(test_2)[i] = stringi::stri_join(c(names(test)[i], '2'), collapse = '_')
              }
              test_0.5 = foreach(i = 1:ncol(test), .combine = cbind) %do% {
                test[, i] ** 0.5
              }
              test_0.5 = as.data.frame(test_0.5)
              for(i in 1:ncol(test_0.5)){
                names(test_0.5)[i] = stringi::stri_join(c(names(test)[i], '0.5'), collapse = '_')
              }
              testA = data.frame(id = id_test)
              testB = data.frame(class = classes_test)
              bind_cols(testA, test, test_2, test_0.5, testB)
            })
            
            #>>---- Download ----
            output$Wrangling_result = downloadHandler(
              filename = function(){
                if(length(train_dataset) != 0){
                  paste0('Tiny_Wrangling_Results.zip')
                }
                else{
                  paste0('Empty_File.txt')
                }
              },
              content = function(fname){
                withProgress(message = 'Processing...', value = 0, {
                  if(length(train_dataset) != 0){
                    ##>>---- Reactive files ----
                    write_csv(train_dataset(), 'Tiny_Wrangling_Train.csv')
                    write_csv(test_dataset(), 'Tiny_Wrangling_Test.csv')
                    ##>>---- Zip Process ----
                    fs = list.files(tempdir(), pattern = '^Tiny_Wrangling_.+')
                    zip(zipfile = fname, files = fs)
                    ##>>---- Remove files ----
                    unlink(fs)
                  }else{
                    writeLines('Empty', file)
                  }
                })
              },
              contentType = 'application/zip'
            )
          }else{
            #>>---- Error 1 ----
            W = data.frame(File = 'Fail to load dataset!', Warning = 'Change separator options.')
            text = paste('\nFail to load dataset!\n',
                         'Change separator options.')
            w_plot = ggplot() + 
              annotate('text', x = 4, y = 25, size = 8, label = text) + 
              theme_void()
            
            output$Wrangling_input_data = DT::renderDataTable({
              W
            }, rownames = F)
            output$Wrangling_eda1_input_data = renderPrint({
              W
            })
            output$Wrangling_eda2_input_data = renderPlot({
              w_plot
            })
            output$Wrangling_eda3_input_data = renderPlot({
              w_plot
            })
            output$Wrangling_eda4_input_data = renderPlot({
              w_plot
            })
          }
        }else{
          #>>---- Error 2 ----
          W = data.frame(File = gsub('.+/', '', input$Load_Data[1]), Warning = 'Dataset is not CSV file.')
          text = paste(gsub('.+/', '', input$Load_Data[1]),
                       '\nDataset is not CSV file.')
          w_plot = ggplot() + 
            annotate('text', x = 4, y = 25, size = 8, label = text) + 
            theme_void()
          
          output$Wrangling_input_data = DT::renderDataTable({
            W
          }, rownames = F)
          output$Wrangling_eda1_input_data = renderPrint({
            W
          })
          output$Wrangling_eda2_input_data = renderPlot({
            w_plot
          })
          
          output$Wrangling_eda3_input_data = renderPlot({
            w_plot
          })
          output$Wrangling_eda4_input_data = renderPlot({
            w_plot
          })
        }
      })
    })
  
  ###---- Modeling Main Tab ----
  output$page_Modeling = renderUI({
    sidebarLayout(
      sidebarPanel(
        ###---- Panel Left ----
        div(style = "margin-left: 5%; margin-right: 5%; display: inline-block; 
            width: 90%; text-align: center;",
            
        ), 
        width = 4,
        ####---- Slots ----
        uiOutput('Modeling_slot_1'), uiOutput('Modeling_slot_2'), 
        uiOutput('Modeling_slot_3'), uiOutput('Modeling_slot_4'), 
        uiOutput('Modeling_slot_5'), uiOutput('Modeling_slot_6'), 
        
        ####---- Notification ----
        tags$head(
          tags$style(
            '.shiny-notification {position: fixed;top:15%;left:50%}'
          )
        )
      ),
      ###---- Main Panel ----
      mainPanel(
        tags$style(
          HTML('.dataTables_wrapper .dataTables_length, 
              .dataTables_wrapper .dataTables_filter, 
              .dataTables_wrapper .dataTables_info, 
              .dataTables_wrapper .dataTables_processing, 
              .dataTables_wrapper .dataTables_paginate {color: #ffffff;}
              thead {color: #ffffff;}
              tbody {color: #000000;}'
          )
        ),
        uiOutput('Modeling_panel')
      )
    )
  })
  
  #>---- Modeling Panel Tabs ----
  output$Modeling_panel = renderUI({
    tabsetPanel(
      tabPanel('AUC LDA', plotOutput('Modeling_LDA_auc')),
      tabPanel('DT', plotOutput('Modeling_DT')),
      tabPanel('Confusion Matrix', plotOutput('Modeling_CM')),
      tabPanel('Train Performance', plotOutput('Modeling_perf'))
    )
  })
  #>---- Modeling_slot_1: Load Train and Test data ----
  output$Modeling_slot_1 = renderUI({
    div(style = 'margin-left: 1%; margin-right: 1%; display: inline-block; 
        width: 98%; text-align: center;', 
        fileInput(
          inputId = 'Load_Train_Test_Data', label = 'Load Train and Test dataset',
          accept = '.csv', multiple = T
        )
    )
  })
  #>---- Modeling_slot_2: Threads ----
  output$Modeling_slot_2 = renderUI({
    if(threads > 2){
      div(style = 'margin-left: 1%; margin-right: 1%; display: inline-block; 
        width: 98%; text-align: center; margin-top: -10%;', 
        sliderInput(
          inputId = 'Threads', label = 'Threads to use',
          min = 1, max = threads - 1, value = 1, step = 1, ticks = F
        )
      )
    }
  })
  
  #>---- Modeling_slot_3:Run/Clear Button ----
  output$Modeling_slot_3 = renderUI({
    splitLayout(
      div(style = 'margin-left: 10%; margin-right: 5%; display: inline-block;
          width: 80%; text-align: center;',
          actionButton(
            inputId = 'Modeling_run', label = 'Run', style = 'width: 100%;'
          )
      ),
      div(style = 'margin-left: 7%; margin-right: 10%; display: inline-block;
          width: 80%; text-align: center;',
          actionButton(
            inputId = 'Modeling_clear', label = 'Clear', style = 'width: 100%;'
          )
      )
    )
  })
  #>---- Modeling_slot_4: Download Results Button ----
  output$Modeling_slot_4 = renderUI({
    div(style = 'margin-left: 5%; margin-right: 5%; display: inline-block;
          width: 90%; text-align: center;',
        downloadButton(
          outputId = 'Modeling_result', label = 'Results', style = 'width: 100%;'
        )
    )
  })
  output$Modeling_result = downloadHandler(
    filename = function(){
      paste0('Empty_File.txt')
    },
    content = function(file){
      writeLines('Empty', file)
    }
  )
  
  #>---- Clear Script ----
  observeEvent(
    input$Modeling_clear, {
      #---- Clear AUC LDA ----
      output$Modeling_LDA_auc = renderPlot({
        NULL
      })
      #---- Clear Decision Tree ----
      output$Modeling_DT = renderPlot({
        NULL
      })
      #---- Clear Confusion Matrix ----
      output$Modeling_CM = renderPlot({
        NULL
      })
      #---- Clear General Train Performance ----
      output$Modeling_perf = renderPlot({
        NULL
      })
      #---- Clear download ----
      output$Modeling_result = downloadHandler(
        filename = function(){
          paste0('Empty_File.txt')
        },
        content = function(file){
          writeLines('Empty', file)
        }
      )
    })
  
  #>---- Run Script ----
  observeEvent(
    input$Modeling_run, {
      cl = makeCluster(round(threads * 0.9, 0), type = 'SOCK')
      registerDoSNOW(cl)
      withProgress(message = 'Processing...', value = 0, {
        req(input$Load_Train_Test_Data)
        train = NULL; test = NULL
        file_status = length(grep('\\.csv$', input$Load_Train_Test_Data$name[1])) + 
          length(grep('\\.csv$', input$Load_Train_Test_Data$name[2]))
        
        if(file_status == 2){
          # Load Train and Test file
          train = read.csv(input$Load_Train_Test_Data$datapath[2], header = T)
          test = read.csv(input$Load_Train_Test_Data$datapath[1], header = T)
          
          #---- Multiclass (Not supported in this version) ----
          if(length(unique(train$class)) > 2 | length(unique(test$class)) > 2){
            text = paste('Error in loaded files:\n', 
                         'File Train have: ', length(unique(train$class)), ' classes!\n', 
                         'File Test have: ', length(unique(test$class)), ' classes!\n', 
                         '\nBoth files need to be binary class!')
            w_plot = ggplot() + 
              annotate('text', x = 4, y = 25, size = 8, label = text) + 
              theme_void()
            
            output$Modeling_LDA_auc = renderPlot({
              w_plot
            })
            output$Modeling_DT = renderPlot({
              w_plot
            })
            output$Modeling_CM = renderPlot({
              w_plot
            })
            output$Modeling_perf = renderPlot({
              w_plot
            })
          }
          #---- Binary class ----
          if(length(unique(train$class)) == 2 & length(unique(test$class)) == 2){
            #>>---- Wrangling Process ----
            # Features names to lower and remove whitespace
            names(train) = stringi::stri_trans_tolower(names(train))
            names(train) = gsub(' ', '_', names(train))
            
            # NAs to zero
            train[is.na(train)] = 0
            test[is.na(test)] = 0
            
            # ID and Class as factor
            train = as.data.frame(train)
            id = as.factor(train$id)
            class = as.factor(train$class)
            
            # Remove special characters in Class names
            train$class = gsub('[[:punct:]]', '_', train$class)
            
            # Creating ID column if not exist
            if(length(grep(TRUE, names(train) == 'id')) != 1){
              temp_table = data.frame(id = stringi::stri_join(rep('A', nrow(train)), c(1:nrow(train))))
              train = bind_cols(temp_table, train)
            }
            
            # Removing ID and Class - Train
            classes_train = train$class
            id_train = train$id
            train = train[, -c(grep('^id$|^class$', names(train)))]
            
            # Removing ID and Class - Test
            classes_test = test$class
            id_test = test$id
            test = test[, -c(grep('^id$|^class$', names(test)))]
            
            # Total input features
            input_features = ncol(train)
            
            #>>---- Cond ----
            if(input_features == 6 | input_features == 9| input_features == 12| input_features == 15|input_features == 18){
              #>>---- Input Data - Features = 2 ----
              if(input_features == 6){
                #---- LDA calc ----
                result_lda = foreach(i = 1:(ncol(train) - 1), .combine = rbind) %:%
                  foreach(j = (i + 1):ncol(train), .combine = rbind) %dopar% {
                    t(MASS::lda(classes_train ~ ., train[, c(i, j)], CV = FALSE)[[4]])
                  }
                
                variables_lda = data.frame()
                for(x in 1:2){
                  variables_lda_temp = foreach(i = 1:(ncol(train) - 1), .combine = rbind) %:%
                    foreach(j = (i + 1):ncol(train), .combine = rbind) %dopar% {
                      if(x == 1){return(names(train)[i])}
                      if(x == 2){return(names(train)[j])}
                    }
                  variables_lda_temp = as.data.frame(variables_lda_temp)
                  names(variables_lda_temp) = stringi::stri_join('X', x)
                  if(nrow(variables_lda) == 0){
                    variables_lda = variables_lda_temp
                  }else{
                    variables_lda = bind_cols(variables_lda, variables_lda_temp)
                  }
                }
                output2 = cbind(variables_lda, result_lda)
                names(output2)[3:4] = c('X1.1', 'X2.1')
                data.table::fwrite(output2, paste0('Tiny_Modeling_1_LDA_coef_equations.csv'), nThread = threads)
                
                #---- Applying LDA on Train ----
                lda_matrix = matrix(0, nrow(train), nrow(variables_lda))
                train2 = as.data.frame(lda_matrix)
                count = 1
                for(i in 1:(ncol(train) - 1)){
                  for(j in 1:(ncol(train))){
                    if(count <= nrow(variables_lda)){
                      for (z in 1:nrow(train)){
                        train2[z, count] = result_lda[count, 1] * train[z, i] + result_lda[count, 2] * train[z, j]
                      }
                      names(train2)[count] = paste(variables_lda[count, 1], variables_lda[count, 2], sep = ' X ')
                      count = count + 1
                    }
                  }
                }
                train2 = na.omit(train2)
                
                #---- Applying LDA on Test ----
                lda_matrix = matrix(0, nrow(test), nrow(variables_lda))
                test2 = as.data.frame(lda_matrix)
                count = 1
                for(i in 1:(ncol(test) - 1)){
                  for(j in 1:(ncol(test))){
                    if(count <= nrow(variables_lda)){
                      for (z in 1:nrow(test)){
                        test2[z, count] = result_lda[count, 1] * test[z, i] + result_lda[count, 2] * test[z, j]
                      }
                      names(test2)[count] = paste(variables_lda[count, 1], variables_lda[count, 2], sep = ' X ')
                      count = count + 1
                    }
                  }
                }
                test2 = na.omit(test2)
              }
              #>>---- Input Data - Features = 3 ----
              if(input_features == 9){
                #---- LDA calc ----
                result_lda = foreach(i = 1:(ncol(train) - 2), .combine = rbind) %:% 
                  foreach(j = (i + 1):(ncol(train) - 1), .combine = rbind) %:% 
                  foreach(k = (j + 1):ncol(train), .combine = rbind) %dopar% {
                    t(MASS::lda(classes_train ~ ., train[, c(i, j, k)], CV = FALSE)[[4]])
                  }
                
                variables_lda = data.frame()
                for(x in 1:3){
                  variables_lda_temp = foreach(i = 1:(ncol(train) - 2), .combine = rbind) %:% 
                    foreach(j = (i + 1):(ncol(train) - 1), .combine = rbind) %:% 
                    foreach(k = (j + 1):ncol(train), .combine = rbind) %dopar% {
                      if(x == 1){return(names(train)[i])}
                      if(x == 2){return(names(train)[j])}
                      if(x == 3){return(names(train)[k])}
                    }
                  variables_lda_temp = as.data.frame(variables_lda_temp)
                  names(variables_lda_temp) = stringi::stri_join('X', x)
                  if(nrow(variables_lda) == 0){
                    variables_lda = variables_lda_temp
                  }else{
                    variables_lda = bind_cols(variables_lda, variables_lda_temp)
                  }
                }
                output2 = cbind(variables_lda, result_lda)
                names(output2)[4:6] = c('X1.1', 'X2.1', 'X3.1')
                data.table::fwrite(output2, paste0('Tiny_Modeling_1_LDA_coef_equations.csv'), nThread = threads)
                
                #---- Applying LDA on Train ----
                lda_matrix = matrix(0, nrow(train), nrow(variables_lda))
                train2 = as.data.frame(lda_matrix)
                count = 1
                for(i in 1:(ncol(train) - 2)){
                  for(j in (i + 1):(ncol(train) - 1)){
                    for(k in (j + 1):ncol(train)){
                      for (z in 1:nrow(train)){
                        train2[z, count] = result_lda[count, 1] * train[z, i] + result_lda[count, 2] * train[z, j] + result_lda[count, 3] * train[z, k]
                      }
                      names(train2)[count] = paste(variables_lda[count, 1], variables_lda[count, 2], variables_lda[count, 3], sep = ' X ')
                      count = count + 1
                    }
                  }
                }
                train2 = na.omit(train2)
                
                #---- Applying LDA on Test ----
                lda_matrix = matrix(0, nrow(test), nrow(variables_lda))
                test2 = as.data.frame(lda_matrix)
                count = 1
                for(i in 1:(ncol(test) - 2)){
                  for(j in (i + 1):(ncol(test) - 1)){
                    for(k in (j + 1):ncol(test)){
                      for (z in 1:nrow(test)){
                        test2[z, count] = result_lda[count, 1] * test[z, i] + result_lda[count, 2] * test[z, j] + result_lda[count, 3] * test[z, k]
                      }
                      names(test2)[count] = paste(variables_lda[count, 1], variables_lda[count, 2], variables_lda[count, 3], sep = ' X ')
                      count = count + 1
                    }
                  }
                }
                test2 = na.omit(test2)
              }
              #>>---- Input Data - Features = 4 ----
              if(input_features == 12){
                #---- LDA calc ----
                result_lda = foreach(i = 1:(ncol(train) - 3), .combine = rbind) %:% 
                  foreach(j = (i + 1):(ncol(train) - 2), .combine = rbind) %:% 
                  foreach(k = (j + 1):(ncol(train) - 1), .combine = rbind) %:% 
                  foreach(l = (k + 1):ncol(train), .combine = rbind) %dopar% {
                    t(MASS::lda(classes_train ~ ., train[, c(i, j, k, l)], CV = FALSE)[[4]])
                  }
                
                variables_lda = data.frame()
                for(x in 1:4){
                  variables_lda_temp = foreach(i = 1:(ncol(train) - 3), .combine = rbind) %:% 
                    foreach(j = (i + 1):(ncol(train) - 2), .combine = rbind) %:% 
                    foreach(k = (j + 1):(ncol(train) - 1), .combine = rbind) %:% 
                    foreach(l = (k + 1):ncol(train), .combine = rbind) %dopar% {
                      if(x == 1){return(names(train)[i])}
                      if(x == 2){return(names(train)[j])}
                      if(x == 3){return(names(train)[k])}
                      if(x == 4){return(names(train)[l])}
                    }
                  variables_lda_temp = as.data.frame(variables_lda_temp)
                  names(variables_lda_temp) = stringi::stri_join('X', x)
                  if(nrow(variables_lda) == 0){
                    variables_lda = variables_lda_temp
                  }else{
                    variables_lda = bind_cols(variables_lda, variables_lda_temp)
                  }
                }
                output2 = cbind(variables_lda, result_lda)
                names(output2)[5:8] = c('X1.1', 'X2.1', 'X3.1', 'X4.1')
                data.table::fwrite(output2, paste0('Tiny_Modeling_1_LDA_coef_equations.csv'), nThread = threads)
                
                #---- Applying LDA on Train ----
                lda_matrix = matrix(0, nrow(train), nrow(variables_lda))
                train2 = as.data.frame(lda_matrix)
                count = 1
                for(i in 1:(ncol(train) - 3)){
                  for(j in (i + 1):(ncol(train) - 2)){
                    for(k in (j + 1):(ncol(train) - 1)){
                      for(l in (k + 1):ncol(train)){
                        for (z in 1:nrow(train)){
                          train2[z, count] = result_lda[count, 1] * train[z, i] + result_lda[count, 2] * train[z, j] + result_lda[count, 3] * train[z, k] + result_lda[count, 4] * train[z, l]
                        }
                        names(train2)[count] = paste(variables_lda[count, 1], variables_lda[count, 2], variables_lda[count, 3], variables_lda[count, 4], sep = ' X ')
                        count = count + 1
                      }
                    }
                  }
                }
                train2 = na.omit(train2)
                
                #---- Applying LDA on Test ----
                lda_matrix = matrix(0, nrow(test), nrow(variables_lda))
                test2 = as.data.frame(lda_matrix)
                count = 1
                for(i in 1:(ncol(test) - 3)){
                  for(j in (i + 1):(ncol(test) - 2)){
                    for(k in (j + 1):(ncol(test) - 1)){
                      for(l in (k + 1):ncol(test)){
                        for (z in 1:nrow(test)){
                          test2[z, count] = result_lda[count, 1] * test[z, i] + result_lda[count, 2] * test[z, j] + result_lda[count, 3] * test[z, k] + result_lda[count, 4] * test[z, l]
                        }
                        names(test2)[count] = paste(variables_lda[count, 1], variables_lda[count, 2], variables_lda[count, 3], variables_lda[count, 4], sep = ' X ')
                        count = count + 1
                      }
                    }
                  }
                }
                test2 = na.omit(test2)
              }
              #>>---- Input Data - Features = 5 ----
              if(input_features == 15){
                #---- LDA calc ----
                result_lda = foreach(i = 1:(ncol(train) - 4), .combine = rbind) %:% 
                  foreach(j = (i + 1):(ncol(train) - 3), .combine = rbind) %:% 
                  foreach(k = (j + 1):(ncol(train) - 2), .combine = rbind) %:% 
                  foreach(l = (k + 1):(ncol(train) - 1), .combine = rbind) %:% 
                  foreach(m = (l + 1):ncol(train), .combine = rbind) %dopar% {
                    t(MASS::lda(classes_train ~ ., train[, c(i, j, k, l, m)], CV = FALSE)[[4]])
                  }
                
                variables_lda = data.frame()
                for(x in 1:5){
                  variables_lda_temp = foreach(i = 1:(ncol(train) - 4), .combine = rbind) %:% 
                    foreach(j = (i + 1):(ncol(train) - 3), .combine = rbind) %:% 
                    foreach(k = (j + 1):(ncol(train) - 2), .combine = rbind) %:% 
                    foreach(l = (k + 1):(ncol(train) - 1), .combine = rbind) %:% 
                    foreach(m = (l + 1):ncol(train), .combine = rbind) %dopar% {
                      if(x == 1){return(names(train)[i])}
                      if(x == 2){return(names(train)[j])}
                      if(x == 3){return(names(train)[k])}
                      if(x == 4){return(names(train)[l])}
                      if(x == 5){return(names(train)[m])}
                    }
                  variables_lda_temp = as.data.frame(variables_lda_temp)
                  names(variables_lda_temp) = stringi::stri_join('X', x)
                  if(nrow(variables_lda) == 0){
                    variables_lda = variables_lda_temp
                  }else{
                    variables_lda = bind_cols(variables_lda, variables_lda_temp)
                  }
                }
                output2 = cbind(variables_lda, result_lda)
                names(output2)[6:10] = c('X1.1', 'X2.1', 'X3.1', 'X4.1', 'X5.1')
                data.table::fwrite(output2, paste0('Tiny_Modeling_1_LDA_coef_equations.csv'), nThread = threads)
                
                #---- Applying LDA on Train ----
                lda_matrix = matrix(0, nrow(train), nrow(variables_lda))
                train2 = as.data.frame(lda_matrix)
                count = 1
                for(i in 1:(ncol(train) - 4)){
                  for(j in (i + 1):(ncol(train) - 3)){
                    for(k in (j + 1):(ncol(train) - 2)){
                      for(l in (k + 1):(ncol(train) - 1)){
                        for(m in (l + 1):ncol(train)){
                          for (z in 1:nrow(train)){
                            train2[z, count] = result_lda[count, 1] * train[z, i] + result_lda[count, 2] * train[z, j] + result_lda[count, 3] * train[z, k] + result_lda[count, 4] * train[z, l] + result_lda[count, 5] * train[z, m]
                          }
                          names(train2)[count] = paste(variables_lda[count, 1], variables_lda[count, 2], variables_lda[count, 3], variables_lda[count, 4], variables_lda[count, 5], sep = ' X ')
                          count = count + 1
                        }
                      }
                    }
                  }
                }
                train2 = na.omit(train2)
                
                #---- Applying LDA on Test ----
                lda_matrix = matrix(0, nrow(test), nrow(variables_lda))
                test2 = as.data.frame(lda_matrix)
                count = 1
                for(i in 1:(ncol(test) - 4)){
                  for(j in (i + 1):(ncol(test) - 3)){
                    for(k in (j + 1):(ncol(test) - 2)){
                      for(l in (k + 1):(ncol(test) - 1)){
                        for(m in (l + 1):ncol(test)){
                          for (z in 1:nrow(test)){
                            test2[z, count] = result_lda[count, 1] * test[z, i] + result_lda[count, 2] * test[z, j] + result_lda[count, 3] * test[z, k] + result_lda[count, 4] * test[z, l] + result_lda[count, 5] * test[z, m]
                          }
                          names(test2)[count] = paste(variables_lda[count, 1], variables_lda[count, 2], variables_lda[count, 3], variables_lda[count, 4], variables_lda[count, 5], sep = ' X ')
                          count = count + 1
                        }
                      }
                    }
                  }
                }
                test2 = na.omit(test2)
              }
              #>>---- Input Data - Features = 6 ----
              if(input_features == 18){
                #---- LDA calc ----
                result_lda = foreach(i = 1:(ncol(train) - 5), .combine = rbind) %:% 
                  foreach(j = (i + 1):(ncol(train) - 4), .combine = rbind) %:% 
                  foreach(k = (j + 1):(ncol(train) - 3), .combine = rbind) %:% 
                  foreach(l = (k + 1):(ncol(train) - 2), .combine = rbind) %:% 
                  foreach(m = (l + 1):(ncol(train) - 1), .combine = rbind) %:% 
                  foreach(n = (m + 1):ncol(train), .combine = rbind) %dopar% {
                    t(MASS::lda(classes_train ~ ., train[, c(i, j, k, l, m, n)], CV = FALSE)[[4]])
                  }
                
                variables_lda = data.frame()
                for(x in 1:6){
                  variables_lda_temp = foreach(i = 1:(ncol(train) - 5), .combine = rbind) %:% 
                    foreach(j = (i + 1):(ncol(train) - 4), .combine = rbind) %:% 
                    foreach(k = (j + 1):(ncol(train) - 3), .combine = rbind) %:% 
                    foreach(l = (k + 1):(ncol(train) - 2), .combine = rbind) %:% 
                    foreach(m = (l + 1):(ncol(train) - 1), .combine = rbind) %:% 
                    foreach(n = (m + 1):ncol(train), .combine = rbind) %dopar% {
                      if(x == 1){return(names(train)[i])}
                      if(x == 2){return(names(train)[j])}
                      if(x == 3){return(names(train)[k])}
                      if(x == 4){return(names(train)[l])}
                      if(x == 5){return(names(train)[m])}
                      if(x == 6){return(names(train)[n])}
                    }
                  variables_lda_temp = as.data.frame(variables_lda_temp)
                  names(variables_lda_temp) = stringi::stri_join('X', x)
                  if(nrow(variables_lda) == 0){
                    variables_lda = variables_lda_temp
                  }else{
                    variables_lda = bind_cols(variables_lda, variables_lda_temp)
                  }
                }
                output2 = cbind(variables_lda, result_lda)
                names(output2)[7:12] = c('X1.1', 'X2.1', 'X3.1', 'X4.1', 'X5.1', 'X6.1')
                data.table::fwrite(output2, paste0('Tiny_Modeling_1_LDA_coef_equations.csv'), nThread = threads)
                
                #---- Applying LDA on Train ----
                lda_matrix = matrix(0, nrow(train), nrow(variables_lda))
                train2 = as.data.frame(lda_matrix)
                count = 1
                for(i in 1:(ncol(train) - 5)){
                  for(j in (i + 1):(ncol(train) - 4)){
                    for(k in (j + 1):(ncol(train) - 3)){
                      for(l in (k + 1):(ncol(train) - 2)){
                        for(m in (l + 1):(ncol(train) - 1)){
                          for(n in (m + 1):ncol(train)){
                            for (z in 1:nrow(train)){
                              train2[z, count] = result_lda[count, 1] * train[z, i] + result_lda[count, 2] * train[z, j] + result_lda[count, 3] * train[z, k] + result_lda[count, 4] * train[z, l] + result_lda[count, 5] * train[z, m] + result_lda[count, 6] * train[z, n]
                            }
                            names(train2)[count] = paste(variables_lda[count, 1], variables_lda[count, 2], variables_lda[count, 3], variables_lda[count, 4], variables_lda[count, 5], variables_lda[count, 6], sep = ' X ')
                            count = count + 1
                          }
                        }
                      }
                    }
                  }
                }
                train2 = na.omit(train2)
                
                #---- Applying LDA on Test ----
                lda_matrix = matrix(0, nrow(test), nrow(variables_lda))
                test2 = as.data.frame(lda_matrix)
                count = 1
                for(i in 1:(ncol(test) - 5)){
                  for(j in (i + 1):(ncol(test) - 4)){
                    for(k in (j + 1):(ncol(test) - 3)){
                      for(l in (k + 1):(ncol(test) - 2)){
                        for(m in (l + 1):(ncol(test) - 1)){
                          for(n in (m + 1):ncol(test)){
                            for (z in 1:nrow(test)){
                              test2[z, count] = result_lda[count, 1] * test[z, i] + result_lda[count, 2] * test[z, j] + result_lda[count, 3] * test[z, k] + result_lda[count, 4] * test[z, l] + result_lda[count, 5] * test[z, m] + result_lda[count, 6] * test[z, n]
                            }
                            names(test2)[count] = paste(variables_lda[count, 1], variables_lda[count, 2], variables_lda[count, 3], variables_lda[count, 4], variables_lda[count, 5], variables_lda[count, 6], sep = ' X ')
                            count = count + 1
                          }
                        }
                      }
                    }
                  }
                }
                test2 = na.omit(test2)
              }
              #>>---- Calculating AUC for LDA equations - Train ----
              result_auc_lda = c(1:ncol(train2)) * 0
              for(i in 1:ncol(train2)){
                v1 = train2[, i]
                v2 = classes_train
                result_auc_lda[i] = pROC::auc(v2, v1, parallel = T)
              }
              
              combinations = colnames(train2)
              
              # AUC results
              output3 = data.frame(combinations, result_auc_lda)
              
              #>>---- Calculating AUC for LDA equations - Test ----
              result_auc_lda_test = c(1:ncol(test2)) * 0
              for(i in 1:ncol(test2)) {
                v1 = test2[, i]
                v2 = classes_test
                result_auc_lda_test[i] = pROC::auc(v2, v1, parallel = T)
              }
              combinations_test = colnames(test2)
              
              # AUC results
              output4 = data.frame(combinations_test, result_auc_lda_test)
              
              outputX = bind_cols(output3, output4[, 2])
              names(outputX) = c('Combinations', 'Train', 'Test')
              data.table::fwrite(outputX, paste0('Tiny_Modeling_2_AUC_results_LDA.csv'), nThread = threads)
              
              #>>---- Creating a new dataframe combining previous biomarkers with best LDA equations ----
              n_sel_equ = 5
              output5 = data.frame(output3[, 1:2], output4[, 2])
              output5 = output5[with(output5, order(-result_auc_lda_test,-result_auc_lda)), ]
              
              selected_lda = output5 [1:n_sel_equ, ]
              natributes = ncol(train)
              
              for(i in 1:nrow(selected_lda)){
                for(j in 1:ncol(train2)){
                  if (as.numeric(rownames(selected_lda)[i]) == j){
                    train = data.frame(train, train2[, j])
                    test = data.frame(test, test2[, j])
                    colnames(train)[natributes + i] = colnames(train2)[j]
                    colnames(test)[natributes + i] = colnames(test2)[j]
                  }
                }
              }
              
              train = data.frame(id_train, train, classes_train)
              test = data.frame(id_test, test, classes_test)
              
              data.table::fwrite(train, paste0('Tiny_Modeling_Train_LDA.csv'), nThread = threads)
              data.table::fwrite(test, paste0('Tiny_Modeling_Test_LDA.csv'), nThread = threads)
              
              #>>---- Applying rpart (Decision Tree) model and generating model ----
              set.seed(101)
              DT = rpart::rpart(classes_train ~ ., data = train[, -1])
              sink(paste0('Tiny_Modeling_3_DecisionTree_results_train.txt'))
              summary(DT)
              sink()
              #>>---- Plot AUC LDA ----
              outputX = data.table::melt(outputX)
              
              auc_lda_p1 = ggplot(outputX, aes(x = variable, y = value, fill = variable)) +
                xlab('Dataset') + ylab('AUC') +
                ggdist::stat_halfeye(adjust = 0.5, width = 0.6, .width = 0, justification = -0.2, point_colour = NA) +
                geom_boxplot(width = 0.15, outlier.shape = NA) +
                gghalves::geom_half_point(side = 'l', range_scale = 0.4, alpha = 0.3) +
                coord_cartesian(xlim = c(1.2, NA), clip = "off") +
                theme_minimal() +
                theme(legend.position = "none") 
              
              pdf(paste0('Tiny_Modeling_4_AUC_LDA_1.pdf'))
              plot(auc_lda_p1)
              dev.off()
              
              auc_lda_p2 = qplot(value, data = outputX, geom = 'density', fill = variable, xlab = 'AUC', ylab = 'Density') +
                theme_minimal()
              
              pdf(paste0('Tiny_Modeling_4_AUC_LDA_2.pdf'))
              plot(auc_lda_p2)
              dev.off()
              
              auc_lda_plot = (auc_lda_p1 / auc_lda_p2) + plot_layout(ncol = 2, guides = 'collect')
              
              output$Modeling_LDA_auc = renderPlot({
                auc_lda_plot
              })
              
              #>>---- Plot DT ----
              pdf(paste0('Tiny_Modeling_5_DecisionTree_train.pdf'))
              rpart.plot::rpart.plot(DT, type = 3, clip.right.labs = F, branch = 0.3, under = T)
              dev.off()
              
              output$Modeling_DT = renderPlot({
                rpart.plot::rpart.plot(DT, type = 3, clip.right.labs = F, branch = 0.3, under = T)
              })
              
              #>>---- Plot Confusion Matrix (Test dataset) ----
              set.seed(151)
              prediction =  predict(DT, test[, -1], type = 'class')
              
              CM = caret::confusionMatrix(prediction, as.factor(test[, ncol(test)]))
              MCC = mltools::mcc(prediction, as.factor(test[, ncol(test)]))
              sink(paste0('Tiny_Modeling_6_Confusion_Matrix_on_Test.txt'))
              print(CM)
              print('Mathews Coefficient Correlation:')
              print(MCC)
              sink()
              
              ggplotConfusionMatrix = function(m){
                CM_title = paste('Accuracy', percent_format()(m$overall[1]), 'Kappa', percent_format()(m$overall[2]), 'MCC', round(MCC, 3))
                cm_plot = ggplot(data = as.data.frame(m$table), aes(x = Reference, y = Prediction)) +
                  geom_tile(aes(fill = log(Freq)), colour = 'white') +
                  scale_fill_gradient(low = 'white', high = 'steelblue') +
                  geom_text(aes(x = Reference, y = Prediction, label = Freq)) +
                  theme(legend.position = 'none') +
                  ggtitle(CM_title) +
                  theme(plot.title = element_text(hjust = 0.5))
                return(cm_plot)
              }
              CM_plot = ggplotConfusionMatrix(CM)
              
              pdf(paste0('Tiny_Modeling_7_Confusion_Matrix_test.pdf'))
              plot(CM_plot)
              dev.off()
              
              output$Modeling_CM = renderPlot({
                CM_plot
              })
              
              #>>---- Model Performance on Train subdaset ----
              perf_tab = data.frame()
              sub_set = seq(0.1, 1, 0.05)
              set.seed(201)
              for(i in 1:length(sub_set)){
                sub_train = train[sample(nrow(train), round(nrow(train) * sub_set[i], 0), replace = F), ]
                status_sub_train = length(unique(sub_train$classes_train))
                while(status_sub_train == 1){
                  sub_train = train[sample(nrow(train) , round(nrow(train) * sub_set[i], 0), replace = F), ]
                  status_sub_train = length(unique(sub_train$classes_train))
                }
                pred_sub_train =  predict(DT, sub_train, type = 'class')
                
                temp_tab = data.frame(Size_Sub_TrainSet = sub_set[i])
                temp_CM = caret::confusionMatrix(pred_sub_train, as.factor(sub_train[, ncol(sub_train)]))
                temp_MCC = mltools::mcc(pred_sub_train, as.factor(sub_train[, ncol(sub_train)]))
                
                temp_tab = cbind(temp_tab, as.data.frame(t(temp_CM$byClass))[, c(11, 1, 2, 5:7)])
                temp_tab$MCC = temp_MCC
                
                perf_tab = rbind(perf_tab, temp_tab)
              }
              names(perf_tab) = gsub(' ', '_', names(perf_tab))
              names(perf_tab)[2] = 'Accuracy'
              data.table::fwrite(perf_tab, paste0('Tiny_Modeling_8_Model_Applied_on_SubTrain_Dataset.csv'), nThread = threads)
              
              
              p1 = ggplot(data = perf_tab, aes(x = Size_Sub_TrainSet, y = Accuracy)) +
                geom_bar(stat = 'identity', fill = 'darkblue') +
                coord_flip() +
                theme_minimal()
              
              p2 = ggplot(data = perf_tab, aes(x = Size_Sub_TrainSet, y = Precision)) +
                geom_bar(stat = 'identity', fill = 'darkgray') +
                coord_flip() +
                theme_minimal()
              
              p3 = ggplot(data = perf_tab, aes(x = Size_Sub_TrainSet, y = MCC)) +
                geom_bar(stat = 'identity', fill = 'darkgreen') +
                coord_flip() +
                theme_minimal()
              
              p4 = ggplot(data = perf_tab, aes(x = Size_Sub_TrainSet, y = F1)) +
                geom_bar(stat = 'identity', fill = 'darkred') +
                coord_flip() +
                theme_minimal()
              
              pdf(paste0( 'Tiny_Modeling_9_Model_Performance_Train.pdf'))
              plot(((p1 / p2) | (p3 / p4)) + plot_layout(ncol = 2, guides = 'collect'))
              dev.off()
              
              output$Modeling_perf = renderPlot({
                ((p1 / p2) | (p3 / p4)) + plot_layout(ncol = 2, guides = 'collect')
              })
              
              stopCluster(cl)
              #>>---- Save Model ----
              saveRDS(DT, 'Tiny_Modeling_Prediction_Model.rds')
              
              #>>---- Save features model ----
              FM = data.frame(features = names(test)[-c(1, ncol(test))])
              data.table::fwrite(FM, paste0('Tiny_Modeling_Features_Model.csv'), nThread = threads)
              
              #>>---- Complete file Model ----
              files_to_model = c('Tiny_Modeling_1_LDA_coef_equations.csv', 'Tiny_Modeling_Features_Model.csv', 'Tiny_Modeling_Prediction_Model.rds')
              model_files = list.files(tempdir())
              mod_sel = foreach(i = 1:length(files_to_model), .combine = c) %do% {
                grep(files_to_model[i], model_files)
              }
              model_files = model_files[mod_sel]
              
              zip(zipfile = 'Model.zip', files = model_files)
              
              #>>---- Download ----
              output$Modeling_result = downloadHandler(
                filename = function(){
                  if(length(result_auc_lda) != 0){
                    paste0('Tiny_Modeling_Results.zip')
                  }
                  else{
                    paste0('Empty_File.txt')
                  }
                },
                content = function(fname){
                  withProgress(message = 'Processing...', value = 0, {
                    if(length(result_auc_lda) != 0){
                      ##>>---- Zip Process ----
                      fs = list.files(tempdir(), pattern = '^Tiny_Modeling_.+|Model.zip')
                      zip(zipfile = fname, files = fs)
                      ##>>---- Remove files ----
                      unlink(fs)
                    }else{
                      writeLines('Empty', file)
                    }
                  })
                },
                contentType = 'application/zip'
              )
              
            }else{
              #>>---- Error 1 ----
              text = paste('Error in Train/Test dataset:\n', 
                           'Total of features: ', input_features, '\n', 
                           'Features: ', stringi::stri_join(names(train), collapse = ', '), '\n', 
                           '\nTotal features need to be 6, 9, 12, 15 or 18.')
              w_plot = ggplot() + 
                annotate('text', x = 4, y = 25, size = 8, label = text) + 
                theme_void()
              
              output$Modeling_LDA_auc = renderPlot({
                w_plot
              })
              output$Modeling_DT = renderPlot({
                w_plot
              })
              output$Modeling_CM = renderPlot({
                w_plot
              })
              output$Modeling_perf = renderPlot({
                w_plot
              })
            }
          }
        }else{
          #>>---- Error 2 ----
          text = paste('Error in loaded files:\n', 
                       'File 1: ', gsub('.+/', '', input$Load_Train_Test_Data$name[1]), '\n', 
                       'File 2: ', gsub('.+/', '', input$Load_Train_Test_Data$name[2]), '\n', 
                       '\nBoth files need to be CSV file!')
          w_plot = ggplot() + 
            annotate('text', x = 4, y = 25, size = 8, label = text) + 
            theme_void()
          
          output$Modeling_LDA_auc = renderPlot({
            w_plot
          })
          output$Modeling_DT = renderPlot({
            w_plot
          })
          output$Modeling_CM = renderPlot({
            w_plot
          })
          output$Modeling_perf = renderPlot({
            w_plot
          })
        }
      })
    })
  
  ###---- Prediction Main Tab ----
  output$page_Prediction = renderUI({
    sidebarLayout(
      sidebarPanel(
        ###---- Panel Left ----
        div(style = "margin-left: 5%; margin-right: 5%; display: inline-block; 
            width: 90%; text-align: center;",
            
        ), 
        width = 4,
        ####---- Slots ----
        uiOutput('Prediction_slot_1'), uiOutput('Prediction_slot_2'), 
        uiOutput('Prediction_slot_3'), uiOutput('Prediction_slot_4'), 
        uiOutput('Prediction_slot_5'), uiOutput('Prediction_slot_6'), 
        
        ####---- Notification ----
        tags$head(
          tags$style(
            '.shiny-notification {position: fixed;top:15%;left:50%}'
          )
        )
      ),
      ###---- Main Panel ----
      mainPanel(
        tags$style(
          HTML('.dataTables_wrapper .dataTables_length, 
              .dataTables_wrapper .dataTables_filter, 
              .dataTables_wrapper .dataTables_info, 
              .dataTables_wrapper .dataTables_processing, 
              .dataTables_wrapper .dataTables_paginate {color: #ffffff;}
              thead {color: #ffffff;}
              tbody {color: #000000;}'
          )
        ),
        uiOutput('Prediction_panel')
      )
    )
  })
  #>---- Prediction Panel Tabs ----
  output$Prediction_panel = renderUI({
    tabsetPanel(
      tabPanel('Prediction', DT::dataTableOutput('Prediction_tab')),
      tabPanel('Class Predicted', plotOutput('Class_Predicted_plot'))
    )
  })
  #>---- Prediction_slot_1: Load data to predict class ----
  output$Prediction_slot_1 = renderUI({
    div(style = 'margin-left: 1%; margin-right: 1%; display: inline-block; 
        width: 98%; text-align: center;', 
        fileInput(
          inputId = 'Load_Unseen_Data', label = 'Load Unseen dataset',
          accept = '.csv', multiple = F
        )
    )
  })
  #>---- Prediction_slot_2: Load Model.zip ----
  output$Prediction_slot_2 = renderUI({
    div(style = 'margin-left: 1%; margin-right: 1%; display: inline-block; 
        width: 98%; text-align: center;', 
        fileInput(
          inputId = 'Load_Model_zip', label = 'Load Model.zip', 
          accept = '.zip', multiple = F
        )
    )
  })
  #>---- Prediction_slot_3: Threads ----
  output$Prediction_slot_3 = renderUI({
    if(threads > 2){
      div(style = 'margin-left: 1%; margin-right: 1%; display: inline-block; 
        width: 98%; text-align: center; margin-top: -10%;', 
          sliderInput(
            inputId = 'Threads', label = 'Threads to use',
            min = 1, max = threads - 1, value = 1, step = 1, ticks = F
          )
      )
    }
  })
  #>---- Prediction_slot_4:Run/Clear Button ----
  output$Prediction_slot_4 = renderUI({
    splitLayout(
      div(style = 'margin-left: 10%; margin-right: 5%; display: inline-block;
          width: 80%; text-align: center;',
          actionButton(
            inputId = 'Prediction_run', label = 'Run', style = 'width: 100%;'
          )
      ),
      div(style = 'margin-left: 7%; margin-right: 10%; display: inline-block;
          width: 80%; text-align: center;',
          actionButton(
            inputId = 'Prediction_clear', label = 'Clear', style = 'width: 100%;'
          )
      )
    )
  })
  #>---- Prediction_slot_5: Download Results Button ----
  output$Prediction_slot_5 = renderUI({
    div(style = 'margin-left: 5%; margin-right: 5%; display: inline-block;
          width: 90%; text-align: center;',
        downloadButton(
          outputId = 'Prediction_result', label = 'Results', style = 'width: 100%;'
        )
    )
  })
  output$Prediction_result = downloadHandler(
    filename = function(){
      paste0('Empty_File.txt')
    },
    content = function(file){
      writeLines('Empty', file)
    }
  )
  
  #>---- Clear Script ----
  observeEvent(
    input$Prediction_clear, {
      #---- Clear Prediction ----
      output$Prediction_tab = DT::renderDataTable({
        NULL
      })
      #---- Clear Class Predicted ----
      output$Class_Predicted_plot = renderPlot({
        NULL
      })
      #---- Clear download ----
      output$Prediction_result = downloadHandler(
        filename = function(){
          paste0('Empty_File.txt')
        },
        content = function(file){
          writeLines('Empty', file)
        }
      )
    })
  #>---- Run Script ----
  observeEvent(
    input$Prediction_run, {
      cl = makeCluster(round(threads * 0.9, 0), type = 'SOCK')
      registerDoSNOW(cl)
      withProgress(message = 'Processing...', value = 0, {
        req(input$Load_Unseen_Data)
        req(input$Load_Model_zip)
        
        file_status = length(grep('\\.csv$', input$Load_Unseen_Data$name)) + 
          length(grep('\\.zip$', input$Load_Model_zip$name))
        
        unseen_data = NULL
        lda_coef_equ = NULL
        features_model = NULL
        Model = NULL
        
        if(file_status == 2){
          # Load Unseen dataset
          unseen_data = read.csv(input$Load_Unseen_Data$datapath, header = T)
          
          # Load Model.zip
          unzip(input$Load_Model_zip$datapath, exdir = 'unziped')
          
          model_zip_list = list.files(recursive = T, pattern = 'Tiny_Modeling_.+')
          model_status = length(grep('1_LDA_coef_equations|Features_Model|Prediction_Model', model_zip_list))
          if(model_status == 3){
            lda_coef_equ = readr::read_csv(model_zip_list[grep('1_LDA_coef_equations', model_zip_list)])
            features_model = readr::read_csv(model_zip_list[grep('Features_Model', model_zip_list)])
            Model = readRDS(model_zip_list[grep('Prediction_Model', model_zip_list)])
          }
          unlink(list.files(pattern = 'unziped'), recursive = T)
          
          if(!is.null(unseen_data) & !is.null(lda_coef_equ) & !is.null(features_model) & !is.null(Model)){
            #>>---- Wrangling Process ----
            # Features names to lower and remove whitespace
            names(unseen_data) = stringi::stri_trans_tolower(names(unseen_data))
            names(unseen_data) = gsub(' ', '_', names(unseen_data))
            
            # Creating ID column if not exist
            if(length(grep(TRUE, names(unseen_data) == 'id')) != 1){
              temp_table = data.frame(id = stringi::stri_join(rep('A', nrow(unseen_data)), c(1:nrow(unseen_data))))
              unseen_data = bind_cols(temp_table, unseen_data)
            }
            
            # ID and Class as factor
            unseen_data = as.data.frame(unseen_data)
            id = as.factor(unseen_data$id)
            class = as.factor(unseen_data$class)
            
            # Removing ID and Class
            classes_unseen_data = unseen_data$class
            id_unseen_data = unseen_data$id
            if(ncol(unseen_data) >3){
              unseen_data = unseen_data[, -c(grep('^id$|^class$', names(unseen_data)))]
            }else{
              id_class = grep('^id$|^class$', names(unseen_data))
              f1_name = names(unseen_data)[-id_class]
              unseen_data = as.data.frame(unseen_data[, -id_class])
              names(unseen_data) = f1_name
            }
            
            # Generating new features (x^2 and x^0.5)
            unseen_data_2 = foreach(i = 1:ncol(unseen_data), .combine = cbind) %do% {
              unseen_data[, i] ** 2
            }
            unseen_data_2 = as.data.frame(unseen_data_2)
            for(i in 1:ncol(unseen_data_2)){
              names(unseen_data_2)[i] = stringi::stri_join(c(names(unseen_data)[i], '2'), collapse = '_')
            }
            unseen_data_0.5 = foreach(i = 1:ncol(unseen_data), .combine = cbind) %do% {
              unseen_data[, i] ** 0.5
            }
            unseen_data_0.5 = as.data.frame(unseen_data_0.5)
            for(i in 1:ncol(unseen_data_0.5)){
              names(unseen_data_0.5)[i] = stringi::stri_join(c(names(unseen_data)[i], '0.5'), collapse = '_')
            }
            unseen_data = bind_cols(unseen_data, unseen_data_2, unseen_data_0.5)
            
            # NAs to zero
            unseen_data[is.na(unseen_data)] = 0
            
            # Total input features in unseen dataset
            input_features = ncol(unseen_data)
            
            # Control condition
            pred_data = data.frame()
            pred_class_plot = NULL
            
            #>>---- Cond ----
            if(input_features == 6 | input_features == 9| input_features == 12| input_features == 15|input_features == 18){
              #----- Input Features = 2 -----
              if(input_features == 6){
                #>>---- Wrangling process ----
                variables_lda = as.matrix(lda_coef_equ[, 1:2])
                result_lda = as.matrix(lda_coef_equ[, 3:ncol(lda_coef_equ)])
                
                lda_matrix = matrix(0, nrow(unseen_data), nrow(variables_lda))
                unseen_data2 = as.data.frame(lda_matrix)
                count = 1
                for(i in 1:(ncol(unseen_data) - 1)){
                  for(j in 1:(ncol(unseen_data))){
                    if(count <= nrow(variables_lda)){
                      for (z in 1:nrow(unseen_data)){
                        unseen_data2[z, count] = result_lda[count, 1] * unseen_data[z, i] + result_lda[count, 2] * unseen_data[z, j]
                      }
                      names(unseen_data2)[count] = paste(variables_lda[count, 1], variables_lda[count, 2], sep = ' X ')
                      count = count + 1
                    }
                  }
                }
                unseen_data2 = na.omit(unseen_data2)
                
                unseen_data = dplyr::bind_cols(id_unseen_data, unseen_data, unseen_data2, classes_unseen_data)
                names(unseen_data) = gsub(' ', '\\.', gsub('/', '.', names(unseen_data)))
                names(unseen_data)[c(1, ncol(unseen_data))] = c('id', 'class')
                
                #>>---- Preparing data to prediction ----
                index_feat_data = foreach::foreach(i = 1:nrow(features_model), .combine = c) %do% {
                  grep(paste0('^', features_model$features[i], '$'), names(unseen_data))
                }
                
                unseen_data = unseen_data[, c(1, index_feat_data, ncol(unseen_data))]
                unseen_data = as.data.frame(unseen_data)
                
                #>>---- Applying Model on Unseen dataset ----
                set.seed(201)
                prediction =  predict(Model, unseen_data[, -1], type = 'class')
                
                # Prediction Table
                pred_data = unseen_data[, c(1, ncol(unseen_data))]
                pred_data$predicted = prediction
                data.table::fwrite(pred_data, paste0('Tiny_Prediction_Table_Pred.csv'), nThread = threads)
                
                # Class plot - predicted
                class_pred_data = pred_data %>% count(predicted)
                pred_class_plot = ggplot(data = class_pred_data, aes(x = predicted, y = n)) +
                  geom_bar(stat = 'identity', fill = 'darkblue') +
                  geom_text(aes(x = predicted, y = n, label = n), position = position_stack(vjust = 0.5)) +
                  xlab('Class') +
                  ylab('Frequency') +
                  ggtitle('Prediction on Unseen Data') +
                  theme(plot.title = element_text(hjust = 0.5)) +
                  theme_minimal()
                
                pdf(paste0('Tiny_Prediction_Class_Prediction.pdf'))
                plot(pred_class_plot)
                dev.off()
              }
              #----- Input Features = 3 -----
              if(input_features == 9){
                #>>---- Wrangling process ----
                variables_lda = as.matrix(lda_coef_equ[, 1:3])
                result_lda = as.matrix(lda_coef_equ[, 4:ncol(lda_coef_equ)])
                
                lda_matrix = matrix(0, nrow(unseen_data), nrow(variables_lda))
                unseen_data2 = as.data.frame(lda_matrix)
                count = 1
                for(i in 1:(ncol(unseen_data) - 2)){
                  for(j in (i + 1):(ncol(unseen_data) - 1)){
                    for(k in (j + 1):ncol(unseen_data)){
                      for (z in 1:nrow(unseen_data)){
                        unseen_data2[z, count] = result_lda[count, 1] * unseen_data[z, i] + result_lda[count, 2] * unseen_data[z, j] + result_lda[count, 3] * unseen_data[z, k]
                      }
                      names(unseen_data2)[count] = paste(variables_lda[count, 1], variables_lda[count, 2], variables_lda[count, 3], sep = ' X ')
                      count = count + 1
                    }
                  }
                }
                unseen_data2 = na.omit(unseen_data2)
                
                unseen_data = dplyr::bind_cols(id_unseen_data, unseen_data, unseen_data2, classes_unseen_data)
                names(unseen_data) = gsub(' ', '\\.', gsub('/', '.', names(unseen_data)))
                names(unseen_data)[c(1, ncol(unseen_data))] = c('id', 'class')
                
                #>>---- Preparing data to prediction ----
                index_feat_data = foreach::foreach(i = 1:nrow(features_model), .combine = c) %do% {
                  grep(paste0('^', features_model$features[i], '$'), names(unseen_data))
                }
                
                unseen_data = unseen_data[, c(1, index_feat_data, ncol(unseen_data))]
                unseen_data = as.data.frame(unseen_data)
                
                #>>---- Applying Model on Unseen dataset ----
                set.seed(201)
                prediction =  predict(Model, unseen_data[, -1], type = 'class')
                
                # Prediction Table
                pred_data = unseen_data[, c(1, ncol(unseen_data))]
                pred_data$predicted = prediction
                data.table::fwrite(pred_data, paste0('Tiny_Prediction_Table_Pred.csv'), nThread = threads)
                
                # Class plot - predicted
                class_pred_data = pred_data %>% count(predicted)
                pred_class_plot = ggplot(data = class_pred_data, aes(x = predicted, y = n)) +
                  geom_bar(stat = 'identity', fill = 'darkblue') +
                  geom_text(aes(x = predicted, y = n, label = n), position = position_stack(vjust = 0.5)) +
                  xlab('Class') +
                  ylab('Frequency') +
                  ggtitle('Prediction on Unseen Data') +
                  theme(plot.title = element_text(hjust = 0.5)) +
                  theme_minimal()
                
                pdf(paste0('Tiny_Prediction_Class_Prediction.pdf'))
                plot(pred_class_plot)
                dev.off()
              }
              #----- Input Features = 4 -----
              if(input_features == 12){
                #>>---- Wrangling process ----
                variables_lda = as.matrix(lda_coef_equ[, 1:4])
                result_lda = as.matrix(lda_coef_equ[, 5:ncol(lda_coef_equ)])
                
                lda_matrix = matrix(0, nrow(unseen_data), nrow(variables_lda))
                unseen_data2 = as.data.frame(lda_matrix)
                count = 1
                for(i in 1:(ncol(unseen_data) - 3)){
                  for(j in (i + 1):(ncol(unseen_data) - 2)){
                    for(k in (j + 1):(ncol(unseen_data) - 1)){
                      for(l in (k + 1):ncol(unseen_data)){
                        for (z in 1:nrow(unseen_data)){
                          unseen_data2[z, count] = result_lda[count, 1] * unseen_data[z, i] + result_lda[count, 2] * unseen_data[z, j] + result_lda[count, 3] * unseen_data[z, k] + result_lda[count, 4] * unseen_data[z, l]
                        }
                        names(unseen_data2)[count] = paste(variables_lda[count, 1], variables_lda[count, 2], variables_lda[count, 3], variables_lda[count, 4], sep = ' X ')
                        count = count + 1
                      }
                    }
                  }
                }
                unseen_data2 = na.omit(unseen_data2)
                
                unseen_data = dplyr::bind_cols(id_unseen_data, unseen_data, unseen_data2, classes_unseen_data)
                names(unseen_data) = gsub(' ', '\\.', gsub('/', '.', names(unseen_data)))
                names(unseen_data)[c(1, ncol(unseen_data))] = c('id', 'class')
                
                #>>---- Preparing data to prediction ----
                index_feat_data = foreach::foreach(i = 1:nrow(features_model), .combine = c) %do% {
                  grep(paste0('^', features_model$features[i], '$'), names(unseen_data))
                }
                
                unseen_data = unseen_data[, c(1, index_feat_data, ncol(unseen_data))]
                unseen_data = as.data.frame(unseen_data)
                
                #>>---- Applying Model on Unseen dataset ----
                set.seed(201)
                prediction =  predict(Model, unseen_data[, -1], type = 'class')
                
                # Prediction Table
                pred_data = unseen_data[, c(1, ncol(unseen_data))]
                pred_data$predicted = prediction
                data.table::fwrite(pred_data, paste0('Tiny_Prediction_Table_Pred.csv'), nThread = threads)
                
                # Class plot - predicted
                class_pred_data = pred_data %>% count(predicted)
                pred_class_plot = ggplot(data = class_pred_data, aes(x = predicted, y = n)) +
                  geom_bar(stat = 'identity', fill = 'darkblue') +
                  geom_text(aes(x = predicted, y = n, label = n), position = position_stack(vjust = 0.5)) +
                  xlab('Class') +
                  ylab('Frequency') +
                  ggtitle('Prediction on Unseen Data') +
                  theme(plot.title = element_text(hjust = 0.5)) +
                  theme_minimal()
                
                pdf(paste0('Tiny_Prediction_Class_Prediction.pdf'))
                plot(pred_class_plot)
                dev.off()
              }
              #----- Input Features = 5 -----
              if(input_features == 15){
                #>>---- Wrangling process ----
                variables_lda = as.matrix(lda_coef_equ[, 1:5])
                result_lda = as.matrix(lda_coef_equ[, 6:ncol(lda_coef_equ)])
                
                lda_matrix = matrix(0, nrow(unseen_data), nrow(variables_lda))
                unseen_data2 = as.data.frame(lda_matrix)
                count = 1
                for(i in 1:(ncol(unseen_data) - 4)){
                  for(j in (i + 1):(ncol(unseen_data) - 3)){
                    for(k in (j + 1):(ncol(unseen_data) - 2)){
                      for(l in (k + 1):(ncol(unseen_data) - 1)){
                        for(m in (l + 1):ncol(unseen_data)){
                          for (z in 1:nrow(unseen_data)){
                            unseen_data2[z, count] = result_lda[count, 1] * unseen_data[z, i] + result_lda[count, 2] * unseen_data[z, j] + result_lda[count, 3] * unseen_data[z, k] + result_lda[count, 4] * unseen_data[z, l] + result_lda[count, 5] * unseen_data[z, m]
                          }
                          names(unseen_data2)[count] = paste(variables_lda[count, 1], variables_lda[count, 2], variables_lda[count, 3], variables_lda[count, 4], variables_lda[count, 5], sep = ' X ')
                          count = count + 1
                        }
                      }
                    }
                  }
                }
                unseen_data2 = na.omit(unseen_data2)
                
                unseen_data = dplyr::bind_cols(id_unseen_data, unseen_data, unseen_data2, classes_unseen_data)
                names(unseen_data) = gsub(' ', '\\.', gsub('/', '.', names(unseen_data)))
                names(unseen_data)[c(1, ncol(unseen_data))] = c('id', 'class')
                
                #>>---- Preparing data to prediction ----
                index_feat_data = foreach::foreach(i = 1:nrow(features_model), .combine = c) %do% {
                  grep(paste0('^', features_model$features[i], '$'), names(unseen_data))
                }
                
                unseen_data = unseen_data[, c(1, index_feat_data, ncol(unseen_data))]
                unseen_data = as.data.frame(unseen_data)
                
                #>>---- Applying Model on Unseen dataset ----
                set.seed(201)
                prediction =  predict(Model, unseen_data[, -1], type = 'class')
                
                # Prediction Table
                pred_data = unseen_data[, c(1, ncol(unseen_data))]
                pred_data$predicted = prediction
                data.table::fwrite(pred_data, paste0('Tiny_Prediction_Table_Pred.csv'), nThread = threads)
                
                # Class plot - predicted
                class_pred_data = pred_data %>% count(predicted)
                pred_class_plot = ggplot(data = class_pred_data, aes(x = predicted, y = n)) +
                  geom_bar(stat = 'identity', fill = 'darkblue') +
                  geom_text(aes(x = predicted, y = n, label = n), position = position_stack(vjust = 0.5)) +
                  xlab('Class') +
                  ylab('Frequency') +
                  ggtitle('Prediction on Unseen Data') +
                  theme(plot.title = element_text(hjust = 0.5)) +
                  theme_minimal()
                
                pdf(paste0('Tiny_Prediction_Class_Prediction.pdf'))
                plot(pred_class_plot)
                dev.off()
              }
              #----- Input Features = 6 -----
              if(input_features == 18){
                #>>---- Wrangling process ----
                variables_lda = as.matrix(lda_coef_equ[, 1:6])
                result_lda = as.matrix(lda_coef_equ[, 7:ncol(lda_coef_equ)])
                
                lda_matrix = matrix(0, nrow(unseen_data), nrow(variables_lda))
                unseen_data2 = as.data.frame(lda_matrix)
                count = 1
                for(i in 1:(ncol(unseen_data) - 5)){
                  for(j in (i + 1):(ncol(unseen_data) - 4)){
                    for(k in (j + 1):(ncol(unseen_data) - 3)){
                      for(l in (k + 1):(ncol(unseen_data) - 2)){
                        for(m in (l + 1):(ncol(unseen_data) - 1)){
                          for(n in (m + 1):ncol(unseen_data)){
                            for (z in 1:nrow(unseen_data)){
                              unseen_data2[z, count] = result_lda[count, 1] * unseen_data[z, i] + result_lda[count, 2] * unseen_data[z, j] + result_lda[count, 3] * unseen_data[z, k] + result_lda[count, 4] * unseen_data[z, l] + result_lda[count, 5] * unseen_data[z, m] + result_lda[count, 6] * unseen_data[z, n]
                            }
                            names(unseen_data2)[count] = paste(variables_lda[count, 1], variables_lda[count, 2], variables_lda[count, 3], variables_lda[count, 4], variables_lda[count, 5], variables_lda[count, 6], sep = ' X ')
                            count = count + 1
                          }
                        }
                      }
                    }
                  }
                }
                unseen_data2 = na.omit(unseen_data2)
                
                unseen_data = dplyr::bind_cols(id_unseen_data, unseen_data, unseen_data2, classes_unseen_data)
                names(unseen_data) = gsub(' ', '\\.', gsub('/', '.', names(unseen_data)))
                names(unseen_data)[c(1, ncol(unseen_data))] = c('id', 'class')
                
                #>>---- Preparing data to prediction ----
                index_feat_data = foreach::foreach(i = 1:nrow(features_model), .combine = c) %do% {
                  grep(paste0('^', features_model$features[i], '$'), names(unseen_data))
                }
                
                unseen_data = unseen_data[, c(1, index_feat_data, ncol(unseen_data))]
                unseen_data = as.data.frame(unseen_data)
                
                #>>---- Applying Model on Unseen dataset ----
                set.seed(201)
                prediction =  predict(Model, unseen_data[, -1], type = 'class')
                
                # Prediction Table
                pred_data = unseen_data[, c(1, ncol(unseen_data))]
                pred_data$predicted = prediction
                data.table::fwrite(pred_data, paste0('Tiny_Prediction_Table_Pred.csv'), nThread = threads)
                
                # Class plot - predicted
                class_pred_data = pred_data %>% count(predicted)
                pred_class_plot = ggplot(data = class_pred_data, aes(x = predicted, y = n)) +
                  geom_bar(stat = 'identity', fill = 'darkblue') +
                  geom_text(aes(x = predicted, y = n, label = n), position = position_stack(vjust = 0.5)) +
                  xlab('Class') +
                  ylab('Frequency') +
                  ggtitle('Prediction on Unseen Data') +
                  theme(plot.title = element_text(hjust = 0.5)) +
                  theme_minimal()
                
                pdf(paste0('Tiny_Prediction_Class_Prediction.pdf'))
                plot(pred_class_plot)
                dev.off()
              }
              #>>---- Render Prediction Table ----
              output$Prediction_tab = DT::renderDataTable({
                if(nrow(pred_data) == 0){
                  W = data.frame(File = 'Error in Unseen dataset structure', Warning = 'This file need the same structure/features like Input dataset that generated the Train/Test dataset!')
                  W
                }else{
                  pred_data
                }
              })
              
              #>>---- Plot Class Prediction ----
              output$Class_Predicted_plot = renderPlot({
                if(is.null(pred_class_plot)){
                  text = paste('\n Error in Unseen dataset structure\n',
                               ' This file need the same structure/features like\n',
                               'Input dataset that generated the Train/Test dataset!')
                  ggplot() + 
                    annotate("text", x = 4, y = 25, size = 8, label = text) + 
                    theme_void()
                  
                }else{
                  pred_class_plot
                }
              })
              
              #>>---- Download ----
              if(!is.null(pred_class_plot)){
                output$Prediction_result = downloadHandler(
                  filename = function(){
                    if(nrow(pred_data) != 0){
                      paste0('Tiny_Prediction_Results.zip')
                    }
                    else{
                      paste0('Empty_File.txt')
                    }
                  },
                  content = function(fname){
                    withProgress(message = 'Processing...', value = 0, {
                      if(nrow(pred_data) != 0){
                        ##>>---- Zip Process ----
                        fs = list.files(tempdir(), pattern = '^Tiny_Prediction_.+')
                        zip(zipfile = fname, files = fs)
                        ##>>---- Remove files ----
                        unlink(fs)
                      }else{
                        writeLines('Empty', file)
                      }
                    })
                  },
                  contentType = 'application/zip'
                )
              }else{
                output$Prediction_result = downloadHandler(
                  filename = function(){
                    paste0('Empty_File.txt')
                  },
                  content = function(file){
                    writeLines('Empty', file)
                  }
                )
              }
            }else{
              #>>---- Error 1 ----
              W = data.frame(File = 'The Unseen dataset is not similar to Train/Test dataset.', Warning = paste0('Total of features: ', input_features, ' | Total features need to be 6, 9, 12, 15 or 18'))
              text = paste('Error in Unseen dataset:\n', 
                           'Total of features: ', input_features, '\n', 
                           'Features: ', stringi::stri_join(names(unseen_data), collapse = ', '), '\n', 
                           '\nTotal features need to be 6, 9, 12, 15 or 18.')
              w_plot = ggplot() + 
                annotate('text', x = 4, y = 25, size = 8, label = text) + 
                theme_void()
              
              output$Prediction_tab = DT::renderDataTable({
                W
              })
              output$Class_Predicted_plot = renderPlot({
                w_plot
              })
            }
          }else{
            #>>---- Error 2 ----
            W = data.frame(File = 'Error!', Warning = 'Check the CSV file and/or ZIP file !')
            text = paste('Error in files:\n', 
                         'Some structure problems in CSV and/or ZIP file\n', 
                         '1 - The CSV file need the same structure/features like\n',
                         'Input dataset that generated the Train/Test dataset.\n', 
                         '2 - The ZIP file is not the Model.zip')
            w_plot = ggplot() + 
              annotate('text', x = 4, y = 25, size = 8, label = text) + 
              theme_void()
            
            output$Prediction_tab = DT::renderDataTable({
              W
            })
            output$Class_Predicted_plot = renderPlot({
              w_plot
            })
          }
        }else{
          #>>---- Error 3 ----
          W = data.frame(File = c(gsub('.+/', '', input$Load_Unseen_Data$name), gsub('.+/', '', input$Load_Model_zip$name)), Warning = c('Need to be CSV file.', 'Need to be a ZIP file.'))
          text = paste('Error in loaded files:\n', 
                       'File 1: ', gsub('.+/', '', input$Load_Unseen_Data$name), '\n', 
                       'File 2: ', gsub('.+/', '', input$Load_Model_zip$name), '\n', 
                       '\nFiles need to be CSV and ZIP file, respectively.')
          w_plot = ggplot() + 
            annotate("text", x = 4, y = 25, size = 8, label = text) + 
            theme_void()
          
          output$Prediction_tab = DT::renderDataTable({
            W
          })
          output$Class_Predicted_plot = renderPlot({
            w_plot
          })
        }
      })
      stopCluster(cl)
    })
}


shinyApp(
  ui, 
  server,
  onStart = function() {
    cat("Tiny setup\n")
    
    onStop(function() {
      cat("Tiny stoped!\n")
    })
  }
)

