#--------------------------------------------------#
Requirements:

Ubuntu 18.04 (or higher) -- Ubuntu 20.04 --> tested!
R 3.6.3 (or higher) -- R 4.0 --------------> tested!
R shiny package installed
Web browser -- Mozila Firefox and Chrome --> tested!
#--------------------------------------------------#


#--------------------------------------------------#
After download and uncompress the Tiny_ML.zip:

1- In a terminal, go to the folder Tiny_ML
cd /home/path_in_your_computer/Tiny_ML

2 - Run the file Install.sh to install complementary libraries in the system.
sh Install.sh


3 - Run Tiny_ML
sh Run.sh

If the web browser do not open automaticly:
- Open your web browser;
- Type on the adress bar: 0.0.0.0:3553

#--------------------------------------------------#


#--------------------------------------------------#
This app only will work with:
- Binary class problems;
- csv files;
- Correct structured file:
  - First column named ID (if your data do not have a ID column, Tiny-ML will create)
  - Columns (features) with only numeric data;
  - Last column named Class.
#--------------------------------------------------#


#--------------------------------------------------#
Authors:
rodrigo.almeida@ifsudestemg.edu.br
rafael@fca.unesp.br
#--------------------------------------------------#
