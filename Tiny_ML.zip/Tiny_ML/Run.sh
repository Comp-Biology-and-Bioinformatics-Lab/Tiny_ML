#!/bin/bash

R -e "shiny::runApp('Tiny_ML.R', host = '0.0.0.0', port = 3553)" &
wait
x-www-browser localhost:3553
